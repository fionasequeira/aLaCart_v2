<?php
  $invalid_search='';
  $input='';
  include('../includes/db_connect.php');  
// Starts a session  
  session_start();
  require '../vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;

// Instantiate a client with the credentials from the project1 profile
$dynamoDbClient = DynamoDbClient::factory(array(
    'profile' => 'default',
    'region'  => 'us-east-1',
    'version' => 'latest',
));
// Updates last log in timestamp
  if(!isset($_SESSION['EmailID'])){
    session_destroy();
    header('Location: '.'login.php');

  }
?>

<!-- Directs existing user to livefeed from login page -->
<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
    <title>aLaCart: LiveFeed</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="home.css">
</head>

<body>
    <?php include('../includes/navbar.php'); ?>

    <div class= "container" align= "center" float ="center">
      <p align = "center", float= "center">
         <?php
         echo '<img float="center" align="center" src="recipe.gif" width="200" height="200"><br>';
            echo 'You are all set! Pick your favourite recipe and get started! <br>';
            echo '<br>';
            if(isset($_SESSION['EmailID'])){
              $email = $_SESSION['EmailID'];
              if(isset($_SESSION['fridge'])){              
                $fridgeitems=$_SESSION['fridge'];
              }

              $count = count($fridgeitems);
              echo $fridgeitems[0].'Your Fridge:';

              // while($count != 0){
              //   echo $fridgeitems[$count+1];
              //   $count=$count-1;
              // }

            
                
              }  
        ?>
      </p>
    </div>
  </body>
</html>