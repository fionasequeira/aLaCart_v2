<?php
$aws_access_key_id = "AKIAJDY322FVWJ2AVIHA";
$aws_secret_access_key = "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"
?>
