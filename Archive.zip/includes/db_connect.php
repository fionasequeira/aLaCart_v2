<?php 
    $db = pg_connect("host=localhost port=5434 dbname=postgres user=postgres password=test") or die ("Could not connect to server\n");
?>