<a href="basehome.php" color=white><h4> aLaCart  <img src="cart.png" name="logout" width="100" height="70"></h4></a>
    <a href="logout.php">
    <img align="right" style="float:right; margin-top: -140px; display: inline-block; padding: 10px 10px;"src="Power_button.png" name="logout" width="40" height="40">
    </a>

    <a href="fridge.php">
    <img align="right" style="float:right; margin-top: -140px; margin-right: 100px; display: inline-block; padding: 10px 10px;" src="fridge.png" name="message" width="40" height="40">
    </a>
